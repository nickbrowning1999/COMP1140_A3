drop table Member
drop table Category
drop table Immoveable
drop table Moveable
drop table Course
drop table Privilege
drop table Location
drop table Adminstrator
drop table Acquistion
drop table Reservation
drop table Loan
drop table Catalogue
drop table Staff
drop table Student


CREATE TABLE Student(
stuNo		CHAR(10),		
stuName	VARCHAR(50),		
stuPriv		VARCHAR(50),		
status      VARCHAR(50),		
commentField    VARCHAR(500),	
stuPhone VarChar(15),
stuEmail VARCHAR(50),
courseID VARChar(8),
PRIMARY KEY(stuNo)
)
go

CREATE TABLE Staff(
staffNo CHAR(10),
staffName	VARCHAR(50),	
commentField    VARCHAR(500),
status      VARCHAR(50), 
staffPhone	VarChar(15),
staffEmail	VARCHAR(50),		
PRIMARY KEY(staffNo),
) 
go

CREATE TABLE Catalogue(
resourceID		VARCHAR(10),			
resourceName	VARCHAR(50),		
resourceType	VARCHAR(50),		
resourceDescription  VARCHAR(100),		
resourceAvailability  VARCHAR(50),		
PRIMARY KEY(resourceID),
)
go 

CREATE TABLE Loan(
loanID VarChar(10),
loanDate		date,
returnDate		date,	
memberName VarChar(50),		
resourceID		VARCHAR(10),
PRIMARY KEY(loanID)
) 
go

CREATE TABLE Reservation(
reservationID CHAR(10),
resourceID		CHAR(10),			
resourceBooking	date,		
resourceReturn	date,		
reservationHistroy      VARCHAR(500),		
memberID    VARCHAR(10),			
PRIMARY KEY(reservationID)
) 
go

CREATE TABLE Acquistion(
memberID	CHAR(10),			
acquID VarChar(10),		
acquDescription		VarChar(500),		
resourceName   VarChar(50),
model VarChar(10),
make VarChar(50),
manufacturer VarChar(50),
year	SMALLINT	NOT NULL CHECK(year BETWEEN 2000 AND 9999),
urgency		VARCHAR(50),
PRIMARY KEY(acquID),
) 
go

CREATE TABLE Adminstrator(
vendorCode Char(10),
vendorName VARCHAR(50),
price FLOAT Default 0.00,
fundCode Char(10),
memberID VarChar(10),			
PRIMARY KEY(vendorCode),
) 
go

CREATE TABLE Location(
locationID		VarChar(10),			
locationRoom	VarChar(50),		
locationBuilding	VarChar(50),		
locationCampus     VarChar(50),		
PRIMARY KEY(locationID),
) 
go

CREATE TABLE Privilege(
maximumResources	INTEGER Default 5,			
studentName	VARCHAR(50),
privDescription	VarChar(100),	
category VARCHAR(20),
stuNo Char(10),			
PRIMARY KEY(stuNo),
Foreign key (stuNo) references Student(stuNo) ON UPDATE CASCADE ON DELETE NO ACTION
) 
go

CREATE TABLE Course(
courseID Char(8),
courseName VarChar(30),
semester	TINYINT			NOT NULL CHECK(semester BETWEEN 1 AND 2) ,
year		SMALLINT		NOT NULL CHECK(year BETWEEN 2000 AND 9999),
PRIMARY KEY(courseID),
) 
go

CREATE TABLE Moveable(
resourceName VarChar(30),
categoryName VarChar(30),
make VarChar(30),
manufacturer VarChar(30),
model VarChar(30),
year	SMALLINT	NOT NULL CHECK(year BETWEEN 2000 AND 9999),
assestValue FLOAT DEFAULT 0.00,
resourceID VarChar(10),
categoryID VarChar(10),
PRIMARY KEY(resourceID),
Foreign key (resourceID) references Catalogue(resourceID) ON UPDATE CASCADE ON DELETE NO ACTION
) 
go

CREATE TABLE Immoveable(
resourceName VarChar(50),
classroom VarChar(50),
studio VarChar(50),
lab VarChar(50),
resourceID VarChar(10),
PRIMARY KEY(resourceID),
) 
go

CREATE TABLE Category(
categoryID VarChar(10),
categoryName VarChar(50),
categoryDescription VarChar(500),
maxTime VarChar(20),
PRIMARY KEY(categoryID),
)
go

CREATE TABLE Member(
memberID CHAR(10),
memberName VarChar(50),
memberPhone VarChar(15),
memberEmail VarChar(50),
PRIMARY KEY(memberID)
) 
go



/*Insert*/
INSERT INTO Student VALUES('321586543', 'Nathan Peterman', 'Granted', 'Active', 'Student at UON', '+64 409 796 352', 'nathan.peterman@uon.edu.au','INFT1004')
INSERT INTO Student VALUES('371747587', 'Derek Anderson', 'Granted', 'Active', 'Student at UON', '+64 456 247 399', 'derek.anderson@uon.edu.au','MNGT1001')
INSERT INTO Student VALUES('201883753', 'Josh Allen', 'Granted', 'Active', 'Student at UON', '+64 499 213 911', 'josh.allen@uon.edu.au','SENG1050')
INSERT INTO Student VALUES('309052959', 'Tom Brady', 'Granted', 'Active', 'Student at UON', '+64 489 192 034', 'josh.allen@uon.edu.au','SENG1050')

INSERT INTO Staff VALUES('119938504', 'Sean McDermott', 'Teacher at UON', 'Active', '+64 409 796 352', 'sean.mcdermott@newcastle.edu.au')
INSERT INTO Staff VALUES('115835839', 'Rob Ryan', 'Teacher at UON', 'Active', '+64 456 247 399', 'rob.ryan@newcastle.edu.au')
INSERT INTO Staff VALUES('112745783', 'Kellen Moore', 'Teacher at UON', 'Active', '+64 499 213 911', 'kellen.moore@newcastle.edu.au')

INSERT INTO Catalogue VALUES('440bc0d213', 'Canon Camera', 'Camera', 'A high quality camera', 'Available')
INSERT INTO Catalogue VALUES('6ac7f3c756', 'Snowball Microphone', 'Microphone', 'Highest quality microphone for recording', 'Available')
INSERT INTO Catalogue VALUES('a6157c21ca', 'Outdoor Speaker', 'Speaker', 'Outdoor speaker for your own purpose', 'Available')

INSERT INTO Loan VALUES('9dg3jfp343', '2018-05-01', '2018-05-01', 'Nathan Peterman', '440bc0d213')
INSERT INTO Loan VALUES('j8vfr8ejf8', '2018-06-05', '2018-06-05', 'Derek Anderson', '6ac7f3c756')
INSERT INTO Loan VALUES('za0wejc8f4', '2018-08-19', '2018-08-19', 'Josh Allen', 'a6157c21ca')
INSERT INTO Loan VALUES('ofejo3vmew', '2018-10-19', '2018-10-31', 'Josh Allen', 'a6157c21ca')
INSERT INTO Loan VALUES('v2i4vni2f4', '2018-10-03', '2018-10-04', 'Derek Anderson', '6ac7f3c756')

INSERT INTO Reservation VALUES('cm29f9jfso', '440bc0d213', '2018-05-01', '2018-05-01', 'Freddie Faz', '321586543')
INSERT INTO Reservation VALUES('j203mck03f', '440bc0d213', '2018-06-05', '2018-06-05', 'Che Warren', '321586543')
INSERT INTO Reservation VALUES('9f2jfcn03m', '440bc0d213', '2018-08-19', '2018-08-19', 'Daxter Turner', '321586543') 
INSERT INTO Reservation VALUES('fmeomffp2m', '8774547638', '2018-05-01', '2018-08-19', 'Faz Austin', '321586543') 
INSERT INTO Reservation VALUES('jfmf2if092', '8774547638', '2018-06-05', '2018-08-19', 'Amari Cooper', '321586543')
INSERT INTO Reservation VALUES('owefweoiee', '8774547638', '2018-06-05', '2018-08-19', 'Cameron Newton', '321586543')
INSERT INTO Reservation VALUES('9jfweiofew', '8774547638', '2018-08-19', '2018-08-19', 'Derek Carr', '321586543')
INSERT INTO Reservation VALUES('jifjwij0fe', '8774547638', '2018-08-19', '2018-08-19', 'David Carr', '321586543')
INSERT INTO Reservation VALUES('9f2jfcn024', '440bc0d213', '2018-08-19', '2018-08-19', 'Farrokh Bulsara', '321586543') 

INSERT INTO Acquistion VALUES('321586543', '9409820385', 'rewg', 'Nikon Digital Camera', 'Nikon', 'DSLR D3300', 'Nikon', 2018, 'Not Urgent')
INSERT INTO Acquistion VALUES('321586003', '9403419049', 'grer', 'Yeti Microphone', 'Blue', 'Yeti Microphone', 'Blue', 2018, 'Not Urgent')
INSERT INTO Acquistion VALUES('321493443', '9405893034', 'grew', 'Outdoor Speaker Pack', 'Studio', 'SAGS01', 'Studio', 2018, 'Not Urgent')

INSERT INTO Adminstrator VALUES('3532354274', 'Nikon', 120.00, '9053024593', '321586543')
INSERT INTO Adminstrator VALUES('1019025547', 'Blue', 120.00, '5902819759', '321586543')
INSERT INTO Adminstrator VALUES('9429889529', 'Studio Acoustics', 120.00, '7594832943', '321586543')

INSERT INTO Location VALUES('C217', 'Chemistry', 'Chemistry', 'Callaghan')
INSERT INTO Location VALUES('RW204', 'Richardson Wing', 'Richardson Wing', 'Callaghan')
INSERT INTO Location VALUES('MSW210', 'Biochemistry Lab', 'Medical Sciences West', 'Callaghan')

INSERT INTO Privilege VALUES(5, 'Nathan Peterman', 'Privilege allows them to have obtain a maximum of 5 items', 'Mircophone', '321586543')
INSERT INTO Privilege VALUES(5, 'Derek Anderson', 'Privilege allows them to have obtain a maximum of 5 items', 'Speaker', '371747587')
INSERT INTO Privilege VALUES(5, 'Josh Allen', 'Privilege allows them to have obtain a maximum of 5 items', 'Camera', '201883753')

INSERT INTO Course VALUES('INFT1004', 'Introduction to Programming', 1, 2018)
INSERT INTO Course VALUES('MNGT1001', 'Introduction to Management', 1, 2018)
INSERT INTO Course VALUES('SENG1050', 'Web Technologies', 2, 2018)

INSERT INTO Moveable  VALUES('Canon Camera', 'Camera', 'Canon', 'Canon', 'EOS 6D Mark II', 2018, 120, '440bc0d213', 'f8432fj4jf')
INSERT INTO Moveable  VALUES('Snowball Microphone', 'Microphone', 'Blue', 'Blue', 'Snowball 2', 2018, 120, '6ac7f3c756', 'f84mvko4g4')
INSERT INTO Moveable  VALUES('Outdoor Speaker', 'Speaker', 'Yamaha', 'Yamaha', 'NSAW294W', 2018, 120, 'a6157c21ca', 'f84j9ffwi4')

INSERT INTO Immoveable  VALUES('Chemistry Lab', 'Chemistry Lab', null, null, '8774547638')
INSERT INTO Immoveable  VALUES('Richardson Wing Room', 'Richardson Wing Room', null, null, '8763765475')
INSERT INTO Immoveable  VALUES('Biochemistry Room', 'Biochemistry Room', null, null, '8748658456')

INSERT INTO Category VALUES('f8432fj4jf', 'Camera', 'A camera is a optical instrument used to take images or film.', '2 days')
INSERT INTO Category VALUES('f84mvko4g4', 'Microphone', 'A microphone is a device that translates sound vibrations in the air into electronic signals or scribes them to a recording medium.', '2 hours')
INSERT INTO Category VALUES('f84j9ffwi4', 'Speaker', 'Speakers are output devices used with computer systems', '2 days') 

INSERT INTO Member VALUES('321586543', 'Nathan Peterman', '+64 409 796 352', 'nathan.peterman@uon.edu.au')
INSERT INTO Member VALUES('371747587', 'Derek Anderson', '+64 456 247 399', 'derek.anderson@uon.edu.au')
INSERT INTO Member VALUES('201883753', 'Josh Allen', '+64 499 213 911', 'josh.allen@uon.edu.au')
INSERT INTO Member VALUES('119938504', 'Sean McDermott', '+64 409 796 352', 'sean.mcdermott@newcastle.edu.au')
INSERT INTO Member VALUES('115835839', 'Rob Ryan', '+64 456 247 399', 'rob.ryan@newcastle.edu.au')
INSERT INTO Member VALUES('112745783', 'Kellen Moore', '+64 499 213 911', 'kellen.moore@newcastle.edu.au')

-- Q1: For a staff member with id number 112745783, print hit/her name and phone number.
	Select staffNo, staffName, staffPhone From Staff
	Where staffNo like '%112745783%';

--Q2: Print the name of student(s) who has/have enrolled in the course with course id SENG1050.--
	Select stuName, courseID From Student
	Where courseID like '%SENG1050%';

--Q3: Print the name(s) of the student member(s) who has/have borrowed the category with the name of camera, of which the model is xxx, in this year. Note: camera is a category, and model attribute must be in movable table.--
	Select memberName, categoryName, model, year From Loan l , Moveable m
	Where (categoryName like '%Camera%' AND model like '%EOS 6D Mark II%') AND (l.resourceID=m.resourceID);


--Q4: Find the moveable resource that is the mostly loaned in current month. Print the resource id and resource name.--
	select m.resourceID, m.resourceName, count(*) as mostlyLoaned
	from Moveable m, Loan l
	where m.resourceID=l.resourceID and month(loanDate)=month(SYSDATETIME())
	group by m.resourceID, m.resourceName
	having count(*) >= all(select count(resourceID) from Loan
	where month(loanDate)= month(SYSDATETIME())
	group by resourceID);

--Q5: Print the maximal number of speakers that the student with name xxx can borrow. The student is enrolled in the course with course id yyy. Note: speaker is a category.--
	SELECT studentName, maximumResources, courseID From Privilege, Student, Category
	Where (studentName=stuName AND courseID like '%MNGT1001%') AND (categoryName like '%Speaker%');

--Q6: For each of the three days, including May 1, 2018, June 5, 2018 and August 19, 2018, print the date, the name of the room with name xxx, and the total number of reservations made for the room on each day.--
	select r.resourceID, r.resourceBooking, im.classroom, count(*) as totalReservation
	from  Reservation r, Immoveable im
	where (r.resourceID=im.resourceID) and (resourceBooking like '%2018-05-01%' or resourceBooking like '%2018-06-05%' or resourceBooking like '%2018-08-19%') and (classroom like '%Chemistry Lab%')
	group by r.resourceID, resourceBooking, im.classroom
	having count(*) >= all(select count(resourceBooking) from Reservation
	where (resourceID=resourceID) and (resourceBooking = '2018-05-01' and resourceBooking = '2018-06-05' and resourceBooking = '2018-08-19') and (classroom like '%Chemistry Lab%'));
